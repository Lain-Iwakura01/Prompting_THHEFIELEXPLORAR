// background.js
chrome.downloads.onDeterminingFilename.addListener((downloadItem, suggest) => {
  const imageExtensions = ["jpg", "jpeg", "png", "gif", "bmp", "webp", "svg", "tiff", "ico"];
  const videoExtensions = ["mp4", "mkv", "mov", "avi", "wmv", "flv", "webm", "m4v", "3gp", "3g2", "ogg", "vob"];

  const fileExtension = downloadItem.filename.split('.').pop().toLowerCase();

  if (imageExtensions.includes(fileExtension) || videoExtensions.includes(fileExtension)) {
    suggest({ filename: downloadItem.filename, conflictAction: 'prompt' });
  } else {
    suggest();
  }
});
